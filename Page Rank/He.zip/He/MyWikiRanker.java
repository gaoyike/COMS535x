package He;
import java.io.FileNotFoundException;

/**
 * 
 * @author Yuanyuan Tang
 *
 */
public class MyWikiRanker extends WikiTennisRanker{
	
	public MyWikiRanker(){
		
	}

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		MyWikiRanker mr = new MyWikiRanker();
		PageRank WikiRank = new PageRank("MyWikiGraph.txt", 0.1);
//		PageRank WikiRank = new PageRank("D:\\cs_class\\CS535x\\Homework\\project3\\PavanWikiTennis.txt", 0.1);
		String[] top100rank = WikiRank.topKPageRank(100);
		System.out.println("The highest rank page is " + top100rank[0]);
        String[] top100inDegree = WikiRank.topKInDegree(100);
        System.out.println("The highest in-degree page is " + top100inDegree[0]);
        String[] top100outDegree = WikiRank.topKOutDegree(100);
        System.out.println("The highest out-degree page is " + top100outDegree[0]);
        System.out.println("The similarity between top100pagerank and top100inDegree is " + mr.jaccord(top100rank, top100inDegree));
        System.out.println("The similarity between top100pagerank and top100outDegree is "+ mr.jaccord(top100rank, top100outDegree));
        System.out.println("The similarity between top100inDegree and top100outDegree is " + mr.jaccord(top100inDegree, top100outDegree));
        
        PageRank wikiRank1 = new PageRank("MyWikiGraph.txt", 0.05);        
		String[] top100rank1 = wikiRank1.topKPageRank(100);
		double highestRank1 = wikiRank1.pageRankOf(top100rank1[0]);
		System.out.print("The highest rank page is: ");
		int i = 0;
		while(wikiRank1.pageRankOf(top100rank1[i]) == highestRank1)
		{
			System.out.print(top100rank1[i] + "  ");
			i++;
		}
		System.out.println(" ");
        String[] top100inDegree1 = wikiRank1.topKInDegree(100);
        double highestIndegree1 = wikiRank1.inDegreeOf(top100inDegree1[0]);
        System.out.print("The highest in degree page is " );
        i = 0;
		while(wikiRank1.inDegreeOf(top100inDegree1[i]) == highestIndegree1)
		{
			System.out.print(top100inDegree1[i] + "  ");
			i++;
		}
		System.out.println(" ");      
        String[] top100outDegree1 = wikiRank1.topKOutDegree(100);
        double highestOutdegree1 = wikiRank1.outDegreeOf(top100outDegree1[0]);
        System.out.print("The highest out degree page is " );
        i = 0;
		while(wikiRank1.outDegreeOf(top100outDegree1[i]) == highestOutdegree1)
		{
			System.out.print(top100outDegree1[i] + "  ");
			i++;
		}
		System.out.println(" ");
        System.out.println("The similarity between top100pagerank and top100inDegree is " + mr.jaccord(top100rank1, top100inDegree1));
        System.out.println("The similarity between top100pagerank and top100outDegree is " + mr.jaccord(top100rank1, top100outDegree1));
        System.out.println("The similarity between top100inDegree and top100outDegree is " + mr.jaccord(top100inDegree1, top100outDegree1));

	}

}
