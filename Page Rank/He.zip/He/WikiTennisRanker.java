package He;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;

/**
 * 
 * @author Yuanyuan Tang
 *
 */
public class WikiTennisRanker {
	
	public WikiTennisRanker(){
		
	}
	
	public  double jaccord(String[] s1, String[] s2){
		HashSet<String> d1 = new HashSet(Arrays.asList(s1));
		HashSet<String> d2 = new HashSet(Arrays.asList(s2));
		HashSet<String> terms = new HashSet();
		terms.addAll(d1);
		terms.addAll(d2);
		int intersection = 0;
		Iterator<String> it = d1.iterator();
		while(it.hasNext()){
			String v = it.next();
			if(d2.contains(v))
				intersection++;
		}
		
		return 1.0*intersection/terms.size();
		
	}
	
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		WikiTennisRanker wr = new WikiTennisRanker();
		
		//Epsilon = 0.1
		PageRank tennisRank = new PageRank("WikiTennisGraph.txt", 0.1);
//		PageRank tennisRank = new PageRank("D:\\cs_class\\CS535x\\Homework\\project3\\PavanWikiTennis.txt", 0.1);
//		PageRank tennisRank = new PageRank("D:\\cs_class\\CS535x\\Homework\\project3\\test.txt", 0.1);
		String[] top100rank = tennisRank.topKPageRank(100);
		double highestRank = tennisRank.pageRankOf(top100rank[0]);
		
		System.out.print("The highest rank page is: ");
		int i = 0;
		while(tennisRank.pageRankOf(top100rank[i]) == highestRank)
		{
			System.out.print(top100rank[i] + "  ");
			i++;
		}
		System.out.println(" ");
		
		
        String[] top100inDegree = tennisRank.topKInDegree(100);
        double highestIndegree = tennisRank.inDegreeOf(top100inDegree[0]);
        System.out.print("The highest in degree page is " );
        
        i = 0;
		while(tennisRank.inDegreeOf(top100inDegree[i]) == highestIndegree)
		{
			System.out.print(top100inDegree[i] + "  ");
			i++;
		}
		System.out.println(" ");
        
        
        String[] top100outDegree = tennisRank.topKOutDegree(100);
        double highestOutdegree = tennisRank.outDegreeOf(top100outDegree[0]);
        System.out.print("The highest out degree page is " );
        i = 0;
		while(tennisRank.outDegreeOf(top100outDegree[i]) == highestOutdegree)
		{
			System.out.print(top100outDegree[i] + "  ");
			i++;
		}
		System.out.println(" ");
        
        
        System.out.println("The similarity between top100pagerank and top100inDegree is " + wr.jaccord(top100rank, top100inDegree));
        System.out.println("The similarity between top100pagerank and top100outDegree is " + wr.jaccord(top100rank, top100outDegree));
        System.out.println("The similarity between top100inDegree and top100outDegree is " + wr.jaccord(top100inDegree, top100outDegree));
        
        //Epsilon = 0.05
//		PageRank tennisRank1 = new PageRank("D:\\cs_class\\CS535x\\Homework\\project3\\PavanWikiTennis.txt", 0.05);
        PageRank tennisRank1 = new PageRank("WikiTennisGraph.txt", 0.05);
		String[] top100rank1 = tennisRank1.topKPageRank(100);
		double highestRank1 = tennisRank1.pageRankOf(top100rank1[0]);
		
		System.out.print("The highest rank page is: ");
		i = 0;
		while(tennisRank1.pageRankOf(top100rank1[i]) == highestRank1)
		{
			System.out.print(top100rank1[i] + "  ");
			i++;
		}
		System.out.println(" ");

        String[] top100inDegree1 = tennisRank1.topKInDegree(100);
        double highestIndegree1 = tennisRank1.inDegreeOf(top100inDegree1[0]);
        System.out.print("The highest in degree page is " );
        
        i = 0;
		while(tennisRank1.inDegreeOf(top100inDegree1[i]) == highestIndegree1)
		{
			System.out.print(top100inDegree1[i] + "  ");
			i++;
		}
		System.out.println(" ");
//        System.out.println("The highest in degree page is " + top100inDegree1[0]);
        
        String[] top100outDegree1 = tennisRank1.topKOutDegree(100);
        double highestOutdegree1 = tennisRank1.outDegreeOf(top100outDegree1[0]);
        System.out.print("The highest out degree page is " );
        i = 0;
		while(tennisRank1.outDegreeOf(top100outDegree1[i]) == highestOutdegree1)
		{
			System.out.print(top100outDegree1[i] + "  ");
			i++;
		}
		System.out.println(" ");
        
//        System.out.println("The highest out degree page is " + top100outDegree1[0]);
        System.out.println("The similarity between top100pagerank and top100inDegree is " + wr.jaccord(top100rank1, top100inDegree1));
        System.out.println("The similarity between top100pagerank and top100outDegree is " + wr.jaccord(top100rank1, top100outDegree1));
        System.out.println("The similarity between top100inDegree and top100outDegree is " + wr.jaccord(top100inDegree1, top100outDegree1));
	}

}
