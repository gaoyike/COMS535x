package He;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

/**
 * 
 * @author Yuanyuan Tang
 *
 */
public class PageRank {
	
	private HashMap<String, HashSet<String>> graph;
	private HashMap<String, Double> rankForPage;
	private double beta = 0.8;
/**
 * 
 * @param fileName
 * @param epsilon
 * @throws FileNotFoundException
 */
	public PageRank(String fileName, double epsilon) throws FileNotFoundException{
		File file = new File(fileName);
		Scanner sc = new Scanner(file);
		String line;
//		int numVertices;
		if(sc.hasNextLine()){
		   line = sc.nextLine();
		   Scanner lineScanner = new Scanner(line);
//		   numVertices = lineScanner.nextInt();
		   lineScanner.close();
		}

		graph = new HashMap<String, HashSet<String>>();
		while(sc.hasNextLine()){
			line = sc.nextLine();
			Scanner lineScanner = new Scanner(line);
			String start = lineScanner.next();
			String end = lineScanner.next();
			if(!graph.containsKey(start)){
				HashSet<String> endVertices = new HashSet<String>();
				endVertices.add(end);
				graph.put(start, endVertices);
				if(!graph.containsKey(end)){
					HashSet<String> endVerticesForEnd = new HashSet<String>();
					graph.put(end, endVerticesForEnd);
				}
			}
			else{
				HashSet<String> endVertices = graph.get(start);
				endVertices.add(end);
				graph.put(start, endVertices);
				if(!graph.containsKey(end)){
					HashSet<String> endVerticesForEnd = new HashSet<String>();
					graph.put(end, endVerticesForEnd);
				}
			}
			
		}
		sc.close();
		System.out.println("the number of vertices in the graph is " + graph.size());
		rankForPage = calculateRank(graph, epsilon);
	}
/**
 * 
 * @param graph
 * @param epsilon
 * @return
 */
	public HashMap<String, Double> calculateRank(HashMap<String, HashSet<String>> graph, double epsilon){
		HashMap<String, Double> rank0 = new HashMap<String, Double>();
		HashMap<String, Double> rank1 = new HashMap<String, Double>();
		int numberOfVertices = graph.size();
		Set<String> vertices = graph.keySet();
		Iterator<String> it = vertices.iterator();
		while(it.hasNext()){
			rank0.put(it.next(), new Double(1.0/numberOfVertices));
		}
		
//		System.out.println(rank0.toString());
		
		boolean converged = false;
		int count = 0;
		while(!converged){
			rank1 = computeRank1(graph, rank0);
//			System.out.println(rank1.toString());
			count++;
			if( converged(rank0, rank1, epsilon))
				converged = true;
			rank0 = rank1;
		}
		System.out.println("The number of iteration at the epsilon = "+ epsilon + " is " + count);
		return rank1;
	}
/**
 * 
 * @param rank0
 * @param rank1
 * @param epsilon
 * @return
 */
	public boolean converged(HashMap<String, Double> rank0, HashMap<String, Double> rank1, double epsilon){
		if(rank1.isEmpty())
			return false;
		double norm = 0.0;
		Set<String> vertices = rank0.keySet();
		Iterator<String> it = vertices.iterator();
		while(it.hasNext()){
			String vertex = it.next();
			norm += Math.abs(rank1.get(vertex) - rank0.get(vertex));
		}
		if(norm <= epsilon)
			return true;
		else
			return false;
	}
/**
 * 
 * @param graph
 * @param rank0
 * @return
 */
	public HashMap<String, Double> computeRank1(HashMap<String, HashSet<String>> graph, HashMap<String, Double> rank0){
		HashMap<String, Double> rank1 = new HashMap<String, Double>();
		int numVer = rank0.size();
		Set<String> vertices = rank0.keySet();
		Iterator<String> it = vertices.iterator();
		while(it.hasNext()){
			rank1.put(it.next(), (1-beta)/numVer);
		}
		Iterator<String> it2 = vertices.iterator();
		while(it2.hasNext()){
			String p = it2.next();
			HashSet<String> Q = graph.get(p);
			if(!Q.isEmpty()){
				Iterator<String> it3 = Q.iterator();
				while(it3.hasNext()){
					String q = it3.next();
					Double r = new Double(rank1.get(q) + beta* rank0.get(p) / Q.size());
					rank1.put(q, r);
				}
			}
			else{
				Iterator<String> it4 = vertices.iterator();
				while(it4.hasNext()){
					String q = it4.next();
					Double r = new Double(rank1.get(q) + beta * rank0.get(p)/numVer);
					rank1.put(q, r);
					
				}
			}
			
		}
		
		return rank1;
	}
	//A method named pageRankOf its gets name of vertex of the graph as parameter and returns
	//its page rank.
	public double pageRankOf(String vertexName){
		
		return rankForPage.get(vertexName);
	}
	
	//A method named outDegreeOf its gets name of vertex of the graph as parameter and returns
	//its out degree.
	public int outDegreeOf(String vertexName){
		return graph.get(vertexName).size();
	}
	
	//A method named inDegreeOf its gets name of vertex of the graph as parameter and returns
	//its in degree.
	public int inDegreeOf(String vertexName){
		Set<String> ver = graph.keySet();
		Iterator<String> it = ver.iterator();
		int numInDegree = 0;
		while(it.hasNext()){
			String start = it.next();
			if(graph.get(start).contains(vertexName))
				numInDegree++;
		}
		return numInDegree;
	}
	
	//A method named numEdges that returns number of edges of the graph.
	public int numEdges(){
		Set<String> ver = graph.keySet();
		Iterator<String> it = ver.iterator();
		int numEdge = 0;
		while(it.hasNext()){
			String start = it.next();
			if(!graph.get(start).isEmpty()){
				numEdge += graph.get(start).size();
			}
		}
		return numEdge;
	}
	
	//A method named topKPageRank that gets an integer k as parameter and returns an array (of
	//strings) of pages with top k page ranks.
	public String[] topKPageRank(int k){

		Set<String> ver = rankForPage.keySet();
		ValueForPage[] rankPage = new ValueForPage[ver.size()];
		Iterator<String> it = ver.iterator();
		int i = 0;
		while(it.hasNext()){
			String v = it.next();
			rankPage[i] = new ValueForPage(v, rankForPage.get(v));
			i++;
		}
		Arrays.sort(rankPage, new PageComparator());
		int length = rankPage.length-1;
		String[] result = new String[k];
		for(int j = 0; j<k; j++){
//			System.out.println(rankPage[length - j].name + " " + rankPage[length - j].value);
			result[j]= rankPage[length - j].name;
		}
		return result;
	}
	
	//A method named topKInDegree that gets an integer k as parameter and returns an array (of
	//strings) of pages with top k in degree.
	public String[] topKInDegree(int k){
		Set<String> ver = graph.keySet();
		ValueForPage[] inDegreePage = new ValueForPage[ver.size()];
		Iterator<String> it = ver.iterator();
		int i = 0;
		while(it.hasNext()){
			String vertex = it.next();
			int value = inDegreeOf(vertex);
			inDegreePage[i] = new ValueForPage(vertex, (double)value);
			i++;
		}
		Arrays.sort(inDegreePage, new PageComparator());
		int length = inDegreePage.length-1;
		String[] result = new String[k];
		for(int j = 0; j<k; j++){

			result[j]= inDegreePage[length - j].name;
		}
		return result;
	}
	
	//A method named topKOutDegree that gets an integer k as parameter and returns an array (of
	//strings) of pages with top k out degree.
	public String[] topKOutDegree(int k){
		Set<String> ver = graph.keySet();
		ValueForPage[] outPage = new ValueForPage[ver.size()];
		Iterator<String> it = ver.iterator();
		int i = 0;
		while(it.hasNext()){
			String vertex = it.next();
			int value = outDegreeOf(vertex);
			outPage[i] = new ValueForPage(vertex, (double)value);
			i++;
		}
		Arrays.sort(  outPage, new PageComparator());
		int length = outPage.length-1;
		String[] result = new String[k];
		for(int j = 0; j<k; j++){
			result[j]= outPage[length - j].name;
		}
		return result;
	}
	
	class ValueForPage{
		String name;
		double value;
		ValueForPage(String url, double r){
			name = url;
			value = r;
		}
	}
	
	class PageComparator implements Comparator<ValueForPage>{
		@Override
		public int compare(ValueForPage o1, ValueForPage o2) {
			if(o1.value - o2.value < 0)
				return -1 ;
			else if(o1.value-o2.value==0)
				return 0;
			else
				return 1;
		}
	}
	
	public static void main(String[] args) throws FileNotFoundException{
		PageRank pr = new PageRank("D:\\cs_class\\CS535x\\Homework\\project3\\PavanWikiTennis.txt", 0.1);
//		PageRank pr = new PageRank("D:\\cs_class\\CS535x\\Homework\\project3\\test.txt", 0.0001);
		String[] top100rank = pr.topKPageRank(100);
		
		System.out.println("The highest rank page is " + top100rank[0]);
        String[] top100inDegree = pr.topKInDegree(100);		
        System.out.println("The highest in degree page is " + top100inDegree[0]);
        String[] top100outDegree = pr.topKOutDegree(100);		
        System.out.println("The highest out degree page is " + top100outDegree[0]);
	}

}
